@extends('backend.layouts.app')
@section('content')
<div class="container">
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
    <div class="block">
        <div class="block-header block-header-default">
            <h3 class="block-title text-center"> Update Stock</h3>
            <div class="block-options">
                <a href="{{route('stock.list')}}">
                    <i class="si si-list"></i>
                </a>
                <button type="button" class="btn-block-option" data-toggle="block-option" data-action="state_toggle" data-action-mode="demo">
                    <i class="si si-refresh"></i>
                </button>
                <button type="button" class="btn-block-option" data-toggle="block-option" data-action="content_toggle"><i class="si si-arrow-up"></i></button>
            </div>
        </div>
        <div class="block-content">
            <div class="row justify-content-center py-20">
                <div class="col-xl-6">
                    <form role="form" action="{{route('stock.update',$stock->id) }}" method="post" enctype="multipart/form-data">
                    @csrf
                        <div class="form-group">
                            <div class="form-material">
                                <input type="text" class="form-control" id="color-name" value="{{$stock->product? $stock->product->product_name : 'Null'}}" disabled="">
                                <label for="color-name">Product Name</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-material">
                                <input type="number" class="form-control" id="color-name" value="{{$stock->quantity}}" name="quantity" placeholder="Enter Quantity">
                                <label for="color-name">Quantity<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-material">
                                <input type="text" class="form-control" id="color-name" value="{{$stock->color? $stock->color->color_name : 'Null'}}" disabled="">
                                <label for="color-name">Color Name</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-material">
                                <input type="text" class="form-control" id="color-name" value="{{$stock->size? $stock->size->size_name : 'Null'}}" disabled="">
                                <label for="color-name">Size Name</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-material">
                                <input type="text" class="form-control" id="color-name" value="{{$stock->weight? $stock->weight->weight_name : 'Null'}}" disabled="">
                                <label for="color-name">Weight</label>
                            </div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-alt-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection