<!-- Footer -->
<footer id="page-footer">
    <div class="content py-20 font-size-sm clearfix">
        <div class="float-right">
            Crafted with <i class="fa fa-heart text-pulse"></i> by <a class="font-w600" href="https://bizitbd.com/" target="_blank">BIZ IT BD</a>
        </div>
        <div class="float-left">
            <a class="font-w600" href="/" target="_blank">ChabiKathi</a> &copy; <span class="js-year-copy"></span>
        </div>
    </div>
</footer>
<!-- END Footer -->